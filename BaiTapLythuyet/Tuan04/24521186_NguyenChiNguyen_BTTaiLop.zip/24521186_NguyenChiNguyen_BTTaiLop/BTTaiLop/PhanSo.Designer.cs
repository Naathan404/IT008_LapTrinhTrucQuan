﻿namespace BTTaiLop
{
    partial class PhanSo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.txbMau3 = new System.Windows.Forms.TextBox();
            this.txbTu3 = new System.Windows.Forms.TextBox();
            this.txbMau2 = new System.Windows.Forms.TextBox();
            this.txbMau1 = new System.Windows.Forms.TextBox();
            this.lblMau = new System.Windows.Forms.Label();
            this.lblTu = new System.Windows.Forms.Label();
            this.btnSUB = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblRes = new System.Windows.Forms.Label();
            this.txbTu2 = new System.Windows.Forms.TextBox();
            this.txbTu1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "/";
            // 
            // txbMau3
            // 
            this.txbMau3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txbMau3.Location = new System.Drawing.Point(455, 237);
            this.txbMau3.Name = "txbMau3";
            this.txbMau3.Size = new System.Drawing.Size(102, 22);
            this.txbMau3.TabIndex = 35;
            this.txbMau3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txbTu3
            // 
            this.txbTu3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txbTu3.Location = new System.Drawing.Point(332, 237);
            this.txbTu3.Name = "txbTu3";
            this.txbTu3.Size = new System.Drawing.Size(102, 22);
            this.txbTu3.TabIndex = 34;
            this.txbTu3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txbMau2
            // 
            this.txbMau2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbMau2.Location = new System.Drawing.Point(455, 191);
            this.txbMau2.Name = "txbMau2";
            this.txbMau2.Size = new System.Drawing.Size(102, 22);
            this.txbMau2.TabIndex = 33;
            this.txbMau2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txbMau1
            // 
            this.txbMau1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbMau1.Location = new System.Drawing.Point(455, 150);
            this.txbMau1.Name = "txbMau1";
            this.txbMau1.Size = new System.Drawing.Size(102, 22);
            this.txbMau1.TabIndex = 32;
            this.txbMau1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMau
            // 
            this.lblMau.AutoSize = true;
            this.lblMau.Location = new System.Drawing.Point(474, 120);
            this.lblMau.Name = "lblMau";
            this.lblMau.Size = new System.Drawing.Size(67, 16);
            this.lblMau.TabIndex = 31;
            this.lblMau.Text = "Phan Mau";
            // 
            // lblTu
            // 
            this.lblTu.AutoSize = true;
            this.lblTu.Location = new System.Drawing.Point(346, 120);
            this.lblTu.Name = "lblTu";
            this.lblTu.Size = new System.Drawing.Size(57, 16);
            this.lblTu.TabIndex = 30;
            this.lblTu.Text = "Phan Tu";
            // 
            // btnSUB
            // 
            this.btnSUB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSUB.Location = new System.Drawing.Point(455, 302);
            this.btnSUB.Name = "btnSUB";
            this.btnSUB.Size = new System.Drawing.Size(75, 23);
            this.btnSUB.TabIndex = 29;
            this.btnSUB.Text = "SUB";
            this.btnSUB.UseVisualStyleBackColor = false;
            this.btnSUB.Click += new System.EventHandler(this.btnSUB_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAdd.Location = new System.Drawing.Point(359, 302);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 28;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(231, 191);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(48, 16);
            this.lblNum2.TabIndex = 27;
            this.lblNum2.Text = "Num 2:";
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(231, 153);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(48, 16);
            this.lblNum1.TabIndex = 26;
            this.lblNum1.Text = "Num 1:";
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Location = new System.Drawing.Point(231, 237);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(67, 16);
            this.lblRes.TabIndex = 25;
            this.lblRes.Text = "RESULT: ";
            // 
            // txbTu2
            // 
            this.txbTu2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbTu2.Location = new System.Drawing.Point(332, 191);
            this.txbTu2.Name = "txbTu2";
            this.txbTu2.Size = new System.Drawing.Size(102, 22);
            this.txbTu2.TabIndex = 24;
            this.txbTu2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txbTu1
            // 
            this.txbTu1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbTu1.Location = new System.Drawing.Point(332, 150);
            this.txbTu1.Name = "txbTu1";
            this.txbTu1.Size = new System.Drawing.Size(102, 22);
            this.txbTu1.TabIndex = 23;
            this.txbTu1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(438, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 16);
            this.label1.TabIndex = 39;
            this.label1.Text = "/";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(438, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 16);
            this.label2.TabIndex = 40;
            this.label2.Text = "/";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(300, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(299, 69);
            this.label4.TabIndex = 41;
            this.label4.Text = "PHAN SO";
            // 
            // PhanSo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 412);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txbMau3);
            this.Controls.Add(this.txbTu3);
            this.Controls.Add(this.txbMau2);
            this.Controls.Add(this.txbMau1);
            this.Controls.Add(this.lblMau);
            this.Controls.Add(this.lblTu);
            this.Controls.Add(this.btnSUB);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.txbTu2);
            this.Controls.Add(this.txbTu1);
            this.Name = "PhanSo";
            this.Text = "PhanSo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txbMau3;
        private System.Windows.Forms.TextBox txbTu3;
        private System.Windows.Forms.TextBox txbMau2;
        private System.Windows.Forms.TextBox txbMau1;
        private System.Windows.Forms.Label lblMau;
        private System.Windows.Forms.Label lblTu;
        private System.Windows.Forms.Button btnSUB;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.TextBox txbTu2;
        private System.Windows.Forms.TextBox txbTu1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}
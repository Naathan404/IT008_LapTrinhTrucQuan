﻿namespace BTTaiLop
{
    partial class SoPhuc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSUB = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblRes = new System.Windows.Forms.Label();
            this.txbThuc2 = new System.Windows.Forms.TextBox();
            this.txbThuc1 = new System.Windows.Forms.TextBox();
            this.lblThuc = new System.Windows.Forms.Label();
            this.lblAo = new System.Windows.Forms.Label();
            this.txbAo2 = new System.Windows.Forms.TextBox();
            this.txbAo1 = new System.Windows.Forms.TextBox();
            this.txbAo3 = new System.Windows.Forms.TextBox();
            this.txbThuc3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSUB
            // 
            this.btnSUB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSUB.Location = new System.Drawing.Point(413, 289);
            this.btnSUB.Name = "btnSUB";
            this.btnSUB.Size = new System.Drawing.Size(75, 23);
            this.btnSUB.TabIndex = 13;
            this.btnSUB.Text = "SUB";
            this.btnSUB.UseVisualStyleBackColor = false;
            this.btnSUB.Click += new System.EventHandler(this.btnSUB_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAdd.Location = new System.Drawing.Point(317, 289);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(189, 178);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(48, 16);
            this.lblNum2.TabIndex = 11;
            this.lblNum2.Text = "Num 2:";
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(189, 140);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(48, 16);
            this.lblNum1.TabIndex = 10;
            this.lblNum1.Text = "Num 1:";
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Location = new System.Drawing.Point(189, 224);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(67, 16);
            this.lblRes.TabIndex = 9;
            this.lblRes.Text = "RESULT: ";
            // 
            // txbThuc2
            // 
            this.txbThuc2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbThuc2.Location = new System.Drawing.Point(290, 178);
            this.txbThuc2.Name = "txbThuc2";
            this.txbThuc2.Size = new System.Drawing.Size(102, 22);
            this.txbThuc2.TabIndex = 8;
            this.txbThuc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbThuc2.TextChanged += new System.EventHandler(this.txbThuc2_TextChanged);
            // 
            // txbThuc1
            // 
            this.txbThuc1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbThuc1.Location = new System.Drawing.Point(290, 137);
            this.txbThuc1.Name = "txbThuc1";
            this.txbThuc1.Size = new System.Drawing.Size(102, 22);
            this.txbThuc1.TabIndex = 7;
            this.txbThuc1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbThuc1.TextChanged += new System.EventHandler(this.txbThuc1_TextChanged);
            // 
            // lblThuc
            // 
            this.lblThuc.AutoSize = true;
            this.lblThuc.Location = new System.Drawing.Point(304, 107);
            this.lblThuc.Name = "lblThuc";
            this.lblThuc.Size = new System.Drawing.Size(71, 16);
            this.lblThuc.TabIndex = 14;
            this.lblThuc.Text = "Phan Thuc";
            // 
            // lblAo
            // 
            this.lblAo.AutoSize = true;
            this.lblAo.Location = new System.Drawing.Point(432, 107);
            this.lblAo.Name = "lblAo";
            this.lblAo.Size = new System.Drawing.Size(58, 16);
            this.lblAo.TabIndex = 15;
            this.lblAo.Text = "Phan Ao";
            // 
            // txbAo2
            // 
            this.txbAo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbAo2.Location = new System.Drawing.Point(413, 178);
            this.txbAo2.Name = "txbAo2";
            this.txbAo2.Size = new System.Drawing.Size(102, 22);
            this.txbAo2.TabIndex = 17;
            this.txbAo2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbAo2.TextChanged += new System.EventHandler(this.txbAo2_TextChanged);
            // 
            // txbAo1
            // 
            this.txbAo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txbAo1.Location = new System.Drawing.Point(413, 137);
            this.txbAo1.Name = "txbAo1";
            this.txbAo1.Size = new System.Drawing.Size(102, 22);
            this.txbAo1.TabIndex = 16;
            this.txbAo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbAo1.TextChanged += new System.EventHandler(this.txbAo1_TextChanged);
            // 
            // txbAo3
            // 
            this.txbAo3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txbAo3.Location = new System.Drawing.Point(413, 224);
            this.txbAo3.Name = "txbAo3";
            this.txbAo3.Size = new System.Drawing.Size(102, 22);
            this.txbAo3.TabIndex = 19;
            this.txbAo3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbAo3.TextChanged += new System.EventHandler(this.txbAo3_TextChanged);
            // 
            // txbThuc3
            // 
            this.txbThuc3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txbThuc3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txbThuc3.Location = new System.Drawing.Point(290, 224);
            this.txbThuc3.Name = "txbThuc3";
            this.txbThuc3.Size = new System.Drawing.Size(102, 22);
            this.txbThuc3.TabIndex = 18;
            this.txbThuc3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbThuc3.TextChanged += new System.EventHandler(this.txbThuc3_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(521, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 16);
            this.label1.TabIndex = 20;
            this.label1.Text = "i";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(521, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 16);
            this.label2.TabIndex = 21;
            this.label2.Text = "i";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(521, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "i";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(254, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(302, 69);
            this.label4.TabIndex = 23;
            this.label4.Text = "SO PHUC";
            // 
            // SoPhuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txbAo3);
            this.Controls.Add(this.txbThuc3);
            this.Controls.Add(this.txbAo2);
            this.Controls.Add(this.txbAo1);
            this.Controls.Add(this.lblAo);
            this.Controls.Add(this.lblThuc);
            this.Controls.Add(this.btnSUB);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.txbThuc2);
            this.Controls.Add(this.txbThuc1);
            this.Name = "SoPhuc";
            this.Text = "SoPhuc";
            this.Load += new System.EventHandler(this.SoPhuc_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSUB;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.TextBox txbThuc2;
        private System.Windows.Forms.TextBox txbThuc1;
        private System.Windows.Forms.Label lblThuc;
        private System.Windows.Forms.Label lblAo;
        private System.Windows.Forms.TextBox txbAo2;
        private System.Windows.Forms.TextBox txbAo1;
        private System.Windows.Forms.TextBox txbAo3;
        private System.Windows.Forms.TextBox txbThuc3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}
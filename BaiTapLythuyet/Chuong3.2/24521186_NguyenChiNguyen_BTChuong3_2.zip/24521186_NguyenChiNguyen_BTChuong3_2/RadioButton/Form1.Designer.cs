﻿namespace RadioButton
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radChoice3 = new System.Windows.Forms.RadioButton();
            this.radChoice2 = new System.Windows.Forms.RadioButton();
            this.radChoice1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radChoice6 = new System.Windows.Forms.RadioButton();
            this.radChoice5 = new System.Windows.Forms.RadioButton();
            this.radChoice4 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.radChoice3);
            this.groupBox1.Controls.Add(this.radChoice2);
            this.groupBox1.Controls.Add(this.radChoice1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(264, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(267, 135);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tình trạng hôn nhân";
            // 
            // radChoice3
            // 
            this.radChoice3.AutoSize = true;
            this.radChoice3.ForeColor = System.Drawing.Color.Blue;
            this.radChoice3.Location = new System.Drawing.Point(25, 95);
            this.radChoice3.Name = "radChoice3";
            this.radChoice3.Size = new System.Drawing.Size(125, 24);
            this.radChoice3.TabIndex = 2;
            this.radChoice3.TabStop = true;
            this.radChoice3.Text = "Có gia đình";
            this.radChoice3.UseVisualStyleBackColor = true;
            // 
            // radChoice2
            // 
            this.radChoice2.AutoSize = true;
            this.radChoice2.ForeColor = System.Drawing.Color.Blue;
            this.radChoice2.Location = new System.Drawing.Point(25, 67);
            this.radChoice2.Name = "radChoice2";
            this.radChoice2.Size = new System.Drawing.Size(86, 24);
            this.radChoice2.TabIndex = 1;
            this.radChoice2.TabStop = true;
            this.radChoice2.Text = "Ly hôn";
            this.radChoice2.UseVisualStyleBackColor = true;
            // 
            // radChoice1
            // 
            this.radChoice1.AutoSize = true;
            this.radChoice1.ForeColor = System.Drawing.Color.Blue;
            this.radChoice1.Location = new System.Drawing.Point(25, 39);
            this.radChoice1.Name = "radChoice1";
            this.radChoice1.Size = new System.Drawing.Size(105, 24);
            this.radChoice1.TabIndex = 0;
            this.radChoice1.TabStop = true;
            this.radChoice1.Text = "Độc thân";
            this.radChoice1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.radChoice6);
            this.groupBox2.Controls.Add(this.radChoice5);
            this.groupBox2.Controls.Add(this.radChoice4);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(264, 222);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(267, 135);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thu nhập một tháng";
            // 
            // radChoice6
            // 
            this.radChoice6.AutoSize = true;
            this.radChoice6.ForeColor = System.Drawing.Color.Blue;
            this.radChoice6.Location = new System.Drawing.Point(25, 95);
            this.radChoice6.Name = "radChoice6";
            this.radChoice6.Size = new System.Drawing.Size(138, 24);
            this.radChoice6.TabIndex = 2;
            this.radChoice6.TabStop = true;
            this.radChoice6.Text = "Trên 20 triệu";
            this.radChoice6.UseVisualStyleBackColor = true;
            // 
            // radChoice5
            // 
            this.radChoice5.AutoSize = true;
            this.radChoice5.ForeColor = System.Drawing.Color.Blue;
            this.radChoice5.Location = new System.Drawing.Point(25, 67);
            this.radChoice5.Name = "radChoice5";
            this.radChoice5.Size = new System.Drawing.Size(121, 24);
            this.radChoice5.TabIndex = 1;
            this.radChoice5.TabStop = true;
            this.radChoice5.Text = "10-20 triệu";
            this.radChoice5.UseVisualStyleBackColor = true;
            // 
            // radChoice4
            // 
            this.radChoice4.AutoSize = true;
            this.radChoice4.ForeColor = System.Drawing.Color.Blue;
            this.radChoice4.Location = new System.Drawing.Point(25, 39);
            this.radChoice4.Name = "radChoice4";
            this.radChoice4.Size = new System.Drawing.Size(111, 24);
            this.radChoice4.TabIndex = 0;
            this.radChoice4.TabStop = true;
            this.radChoice4.Text = "5-10 triệu";
            this.radChoice4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(316, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 66);
            this.button1.TabIndex = 4;
            this.button1.Text = "XÁC NHẬN";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "RadioButton Test";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radChoice3;
        private System.Windows.Forms.RadioButton radChoice2;
        private System.Windows.Forms.RadioButton radChoice1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radChoice6;
        private System.Windows.Forms.RadioButton radChoice5;
        private System.Windows.Forms.RadioButton radChoice4;
        private System.Windows.Forms.Button button1;
    }
}

